# PerApp Spoof (LSPosed module, .apk)

Spoof model device dan/atau CPU & GPU per aplikasi, meniru fitur per-app spoofing PenguinOS Settings.
Sumber referensi: UserSelectedAppSpoofSettings.kt, AdvancedAppSpoofSettings.kt, custom_arrays.xml (celerity).

## Build
GitHub Actions: taruh isi folder ini di root repo, jalankan workflow "Build LSPosed module"
(Actions > Run workflow). APK ada di Artifacts: PerAppSpoof-debug-apk.

Lokal (butuh JDK 17 + Android SDK 34 + Gradle 8.7): `gradle :app:assembleDebug`
Hasil: app/build/outputs/apk/debug/app-debug.apk
Jika api.xposed.info tidak bisa diakses, taruh api-82.jar di app/libs/.

## Pakai
1. Install APK, buka LSPosed > Modul > aktifkan PerApp Spoof.
2. Scope: centang modul ini sendiri dan game target (wajib, LSPosed hanya memasang hook di app yang di-scope).
3. Buka PerApp Spoof, isi package name, pilih opsi, tekan Apply (butuh izin root untuk log dan force-stop).
4. Buka game. Hasil hook juga dicatat ke log.

## Uji hook (disarankan sebelum mencoba game)
Isi package `com.antaru.perappspoof`, Apply, tutup paksa PerApp Spoof, buka lagi, tekan "Cek nilai".
Nilai di bagian Java Build / SystemProperties / GL harus berubah. Bagian "Shell getprop" memang tidak berubah.
Jika berubah tapi app lain (mis. AIDA64) tidak, app itu membaca lewat jalur native atau belum di-scope.

## Log
/data/local/tmp/perapp_spoof.log  (baris APPLY dari aplikasi, baris HOOK dari proses game)
Log Xposed juga berisi baris "[PerApp Spoof]" di LSPosed > Log.

## Batasan
Hook ada di sisi Java (Build.*, SystemProperties, glGetString milik android.opengl). Game yang membaca
properti atau GL langsung dari kode native tidak terpengaruh.
