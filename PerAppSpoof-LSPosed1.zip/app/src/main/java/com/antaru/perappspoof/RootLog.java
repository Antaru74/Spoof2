package com.antaru.perappspoof;

import android.content.Context;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Tulis log ke /data/local/tmp lewat root; bila root gagal, simpan di folder internal modul. */
public final class RootLog {
    private RootLog() {}

    private static final String TAG = "PerAppSpoof";
    private static final String LOCAL_NAME = "perapp_spoof.log";

    /** Jalankan perintah sebagai root. Mengembalikan output bila sukses, null bila gagal. */
    public static String suOut(String cmd) {
        return run(new String[]{"su", "-c", cmd});
    }

    /** Jalankan perintah biasa (tanpa root), misalnya getprop. */
    public static String shOut(String... argv) {
        return run(argv);
    }

    public static boolean su(String cmd) {
        return suOut(cmd) != null;
    }

    private static String run(String[] argv) {
        Process p = null;
        try {
            p = new ProcessBuilder(argv).redirectErrorStream(true).start();
            InputStream in = p.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            int rc = p.waitFor();
            return rc == 0 ? bo.toString("UTF-8") : null;
        } catch (Throwable t) {
            return null;
        } finally {
            if (p != null) p.destroy();
        }
    }

    private static String stamp(String line) {
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        String full = (ts + " " + line).replace("\n", " | ").replace("\r", " ");
        return full.length() > 800 ? full.substring(0, 800) : full;
    }

    public static synchronized boolean append(String line) {
        String full = stamp(line);
        String esc = full.replace("'", "'\\''");
        boolean ok = su("echo '" + esc + "' >> " + Config.LOG_FILE + " && chmod 666 " + Config.LOG_FILE);
        if (!ok) Log.e(TAG, "gagal menulis " + Config.LOG_FILE + " (root?) : " + full);
        return ok;
    }

    public static synchronized void appendLocal(Context c, String line) {
        try (FileWriter w = new FileWriter(new File(c.getFilesDir(), LOCAL_NAME), true)) {
            w.write(stamp(line) + "\n");
        } catch (Throwable ignored) { }
    }

    /** Tulis ke /data/local/tmp; kalau gagal, tulis ke file lokal modul. */
    public static void log(Context c, String line) {
        if (!append(line)) appendLocal(c, line);
    }

    public static String tailLocal(Context c, int lines) {
        try {
            File f = new File(c.getFilesDir(), LOCAL_NAME);
            if (!f.exists()) return "(kosong)";
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            }
            String[] all = bo.toString("UTF-8").split("\n");
            StringBuilder sb = new StringBuilder();
            for (int i = Math.max(0, all.length - lines); i < all.length; i++) sb.append(all[i]).append('\n');
            return sb.toString();
        } catch (Throwable t) {
            return "(tidak terbaca: " + t + ")";
        }
    }
}
