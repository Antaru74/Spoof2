package com.antaru.perappspoof;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {

    /** Di-hook oleh SpoofHook.hookSelf -> true bila modul aktif di LSPosed. */
    static boolean isModuleActive() { return false; }

    private SharedPreferences sp;
    private boolean worldReadable = true;

    private EditText etPkg;
    private Switch swMaster, swModel, swCpuGpu;
    private Spinner spModel, spCpu, spGpu;
    private TextView tvStatus, tvInfo, tvProbe;
    private LinearLayout listBox, probeHost;
    private final List<Profiles.Device> models = new ArrayList<>();
    private final List<Profiles.Cpu> cpuChoices = new ArrayList<>();
    private final List<Profiles.Gpu> gpuChoices = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = Config.openWorldReadable(this);
        } catch (SecurityException e) {
            worldReadable = false;
            sp = getSharedPreferences(Config.PREFS, MODE_PRIVATE);
        }
        setContentView(buildUi());
        reloadModels();
        reloadHardware();
        refresh();

        String s = isModuleActive()
                ? "LSPosed: modul AKTIF"
                : "LSPosed: modul BELUM aktif (aktifkan di LSPosed, centang scope modul ini sendiri, lalu tutup paksa dan buka lagi)";
        if (!worldReadable) s += "\nKonfigurasi TIDAK bisa dibaca game (MODE_WORLD_READABLE ditolak)";
        tvInfo.setText(s);
        new Thread(() -> {
            final boolean root = RootLog.su("id");
            runOnUiThread(() -> tvInfo.append("\nRoot: " + (root ? "diizinkan"
                    : "DITOLAK (beri izin root ke PerApp Spoof di KernelSU Next)")));
        }).start();
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setPadding(0, dp(12), 0, dp(4));
        tv.setTextSize(15);
        return tv;
    }

    private Button button(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setOnClickListener(l);
        return bt;
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(48));
        sv.addView(root);

        swMaster = new Switch(this);
        swMaster.setText("Aktifkan spoofing (master)");
        swMaster.setChecked(Config.enabled(sp));
        swMaster.setOnCheckedChangeListener((v, on) -> setMaster(on));
        root.addView(swMaster);

        tvInfo = new TextView(this);
        tvInfo.setPadding(0, dp(8), 0, 0);
        root.addView(tvInfo);

        root.addView(label("Package name aplikasi/game"));
        etPkg = new EditText(this);
        etPkg.setHint("contoh: com.mobile.legends");
        etPkg.setSingleLine(true);
        etPkg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(etPkg);

        swModel = new Switch(this);
        swModel.setText("Spoof model device");
        swModel.setChecked(true);
        swModel.setPadding(0, dp(16), 0, 0);
        root.addView(swModel);
        spModel = new Spinner(this);
        root.addView(spModel);
        root.addView(button("Profil kustom baru", v -> showCustomDialog()));

        swCpuGpu = new Switch(this);
        swCpuGpu.setText("Spoof CPU & GPU (saja)");
        swCpuGpu.setPadding(0, dp(16), 0, 0);
        root.addView(swCpuGpu);
        root.addView(label("CPU"));
        spCpu = new Spinner(this);
        root.addView(spCpu);
        root.addView(label("GPU"));
        spGpu = new Spinner(this);
        root.addView(spGpu);
        root.addView(button("Hardware kustom baru", v -> showCustomHardwareDialog()));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(20);
        root.addView(button("Apply", v -> onApply()), lp);

        tvStatus = new TextView(this);
        tvStatus.setPadding(0, dp(12), 0, dp(12));
        root.addView(tvStatus);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText("Daftar app terkonfigurasi");
        t.setTextSize(16);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(button("Clear all", v -> confirmClearAll()));
        root.addView(head);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        root.addView(label("Diagnosa"));
        TextView hint = new TextView(this);
        hint.setText("Uji: isi package com.antaru.perappspoof, Apply, tutup paksa app ini, buka lagi, lalu tekan Cek nilai.");
        root.addView(hint);
        root.addView(button("Cek nilai (uji hook)", v -> runProbe()));
        root.addView(button("Lihat log", v -> showLog()));
        tvProbe = new TextView(this);
        tvProbe.setTypeface(android.graphics.Typeface.MONOSPACE);
        tvProbe.setTextSize(12);
        tvProbe.setTextIsSelectable(true);
        tvProbe.setPadding(0, dp(8), 0, 0);
        root.addView(tvProbe);
        probeHost = new LinearLayout(this);
        root.addView(probeHost);

        TextView foot = new TextView(this);
        foot.setText("Log: " + Config.LOG_FILE);
        foot.setPadding(0, dp(16), 0, 0);
        root.addView(foot);
        return sv;
    }

    private void status(String s) { tvStatus.setText(s); }

    private void reloadModels() {
        models.clear();
        models.addAll(Profiles.DEVICES);
        models.addAll(Config.custom(sp));
        List<String> labels = new ArrayList<>();
        for (Profiles.Device d : models) labels.add(d.label);
        spModel.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
    }

    private void reloadHardware() {
        cpuChoices.clear();
        cpuChoices.addAll(Profiles.CPUS);
        cpuChoices.addAll(Config.customCpus(sp));
        gpuChoices.clear();
        gpuChoices.addAll(Profiles.GPUS);
        gpuChoices.addAll(Config.customGpus(sp));
        List<String> cl = new ArrayList<>();
        cl.add("None");
        for (Profiles.Cpu c : cpuChoices) cl.add(c.label);
        List<String> gl = new ArrayList<>();
        gl.add("None");
        for (Profiles.Gpu g : gpuChoices) gl.add(g.label);
        spCpu.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, cl));
        spGpu.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, gl));
    }

    private static String txt(EditText e) { return e.getText().toString().trim(); }

    private void showCustomHardwareDialog() {
        final String[] hints = {
                "CPU: SoC model (mis. SM8850)",
                "CPU: SoC manufacturer (mis. QTI)",
                "CPU: ro.hardware (opsional, mis. qcom)",
                "CPU: ro.board.platform (opsional)",
                "GPU: renderer (mis. Adreno (TM) 840)",
                "GPU: vendor (mis. Qualcomm)"};
        final EditText[] f = new EditText[hints.length];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        for (int i = 0; i < hints.length; i++) {
            f[i] = new EditText(this);
            f[i].setHint(hints[i]);
            f[i].setSingleLine(true);
            box.addView(f[i]);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("Hardware kustom (isi CPU, GPU, atau keduanya)")
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> {
                    String cpuModel = txt(f[0]);
                    String gpuRenderer = txt(f[4]);
                    if (cpuModel.isEmpty() && gpuRenderer.isEmpty()) {
                        status("FAIL hardware kustom: isi minimal SoC model atau GPU renderer");
                        return;
                    }
                    long id = System.currentTimeMillis();
                    String newCpu = "", newGpu = "";
                    if (!cpuModel.isEmpty()) {
                        newCpu = "CUSTOM_CPU_" + id;
                        List<Profiles.Cpu> l = new ArrayList<>(Config.customCpus(sp));
                        l.add(new Profiles.Cpu(newCpu, cpuModel + " (kustom)",
                                txt(f[1]), cpuModel, txt(f[2]), txt(f[3])));
                        Config.saveCustomCpus(sp, l);
                    }
                    if (!gpuRenderer.isEmpty()) {
                        newGpu = "CUSTOM_GPU_" + id;
                        List<Profiles.Gpu> l = new ArrayList<>(Config.customGpus(sp));
                        l.add(new Profiles.Gpu(newGpu, gpuRenderer + " (kustom)", gpuRenderer, txt(f[5])));
                        Config.saveCustomGpus(sp, l);
                    }
                    reloadHardware();
                    swCpuGpu.setChecked(true);
                    for (int i = 0; i < cpuChoices.size(); i++)
                        if (cpuChoices.get(i).key.equals(newCpu)) spCpu.setSelection(i + 1);
                    for (int i = 0; i < gpuChoices.size(); i++)
                        if (gpuChoices.get(i).key.equals(newGpu)) spGpu.setSelection(i + 1);
                    status("OK hardware kustom disimpan dan dipilih, tekan Apply");
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void refresh() {
        listBox.removeAllViews();
        Map<String, String> perapp = Config.perApp(sp);
        Map<String, String[]> adv = Config.advanced(sp);
        Set<String> all = new LinkedHashSet<>(perapp.keySet());
        all.addAll(adv.keySet());
        if (all.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("Belum ada app terkonfigurasi");
            e.setPadding(0, dp(8), 0, 0);
            listBox.addView(e);
            return;
        }
        List<Profiles.Device> custom = Config.custom(sp);
        for (final String pkg : all) {
            StringBuilder sb = new StringBuilder(pkg);
            String mk = perapp.get(pkg);
            if (mk != null) {
                Profiles.Device d = Profiles.findDevice(mk, custom);
                sb.append("\n  model: ").append(d != null ? d.label : mk + " (hilang)");
            }
            String[] a = adv.get(pkg);
            if (a != null) {
                Profiles.Cpu c = Profiles.findCpu(a[1], Config.customCpus(sp));
                Profiles.Gpu g = Profiles.findGpu(a[0], Config.customGpus(sp));
                sb.append("\n  CPU: ").append(c != null ? c.label : "-");
                sb.append("\n  GPU: ").append(g != null ? g.label : "-");
            }
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(8), 0, dp(8));
            TextView tv = new TextView(this);
            tv.setText(sb.toString());
            row.addView(tv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(button("Hapus", v -> confirmRemove(pkg)));
            listBox.addView(row);
        }
    }

    // ------------------------------------------------------------------ aksi

    private void onApply() {
        final String pkg = etPkg.getText().toString().trim();
        final boolean modelOn = swModel.isChecked();
        final boolean cgOn = swCpuGpu.isChecked();
        final int mi = spModel.getSelectedItemPosition();
        final String modelKey = (mi >= 0 && mi < models.size()) ? models.get(mi).key : null;
        final int ci = spCpu.getSelectedItemPosition();
        final int gi = spGpu.getSelectedItemPosition();
        final String cpuKey = ci > 0 ? cpuChoices.get(ci - 1).key : "";
        final String gpuKey = gi > 0 ? gpuChoices.get(gi - 1).key : "";
        status("Menerapkan...");
        new Thread(() -> {
            final String result = doApply(pkg, modelOn, modelKey, cgOn, cpuKey, gpuKey);
            RootLog.log(this, "APPLY " + result);
            runOnUiThread(() -> { status(result); refresh(); });
        }).start();
    }

    private String doApply(String pkg, boolean modelOn, String modelKey,
                           boolean cgOn, String cpuKey, String gpuKey) {
        if (!pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))
            return "FAIL package name tidak valid: '" + pkg + "'";
        if (!modelOn && !cgOn)
            return "FAIL pkg=" + pkg + " pilih minimal satu: spoof model device atau spoof CPU & GPU";
        try {
            getPackageManager().getPackageInfo(pkg, 0);
        } catch (PackageManager.NameNotFoundException e) {
            return "FAIL pkg=" + pkg + " aplikasi tidak terpasang";
        }
        if (!worldReadable)
            return "FAIL pkg=" + pkg + " LSPosed belum aktif untuk modul ini, konfigurasi tidak akan terbaca game";

        Map<String, String> perapp = new LinkedHashMap<>(Config.perApp(sp));
        Map<String, String[]> adv = new LinkedHashMap<>(Config.advanced(sp));
        if (modelOn) {
            if (modelKey == null) return "FAIL pkg=" + pkg + " profil model belum dipilih";
            perapp.put(pkg, modelKey);
        } else {
            perapp.remove(pkg);
        }
        if (cgOn) {
            if (cpuKey.isEmpty() && gpuKey.isEmpty())
                return "FAIL pkg=" + pkg + " pilih CPU atau GPU (tidak boleh keduanya None)";
            adv.put(pkg, new String[]{gpuKey, cpuKey});
        } else {
            adv.remove(pkg);
        }
        if (!Config.save(sp, Config.enabled(sp), perapp, adv))
            return "FAIL pkg=" + pkg + " gagal menulis konfigurasi (commit false)";

        String stop;
        if (pkg.equals(getPackageName())) {
            stop = "manual (tutup paksa app ini lalu buka lagi)";
        } else {
            stop = RootLog.su("am force-stop " + pkg) ? "ok" : "gagal (root?)";
        }
        return "OK pkg=" + pkg + " model=" + (modelOn ? modelKey : "-")
                + " cpu=" + (cgOn && !cpuKey.isEmpty() ? cpuKey : "-")
                + " gpu=" + (cgOn && !gpuKey.isEmpty() ? gpuKey : "-")
                + " forceStop=" + stop;
    }

    private void setMaster(final boolean on) {
        final Map<String, String> perapp = Config.perApp(sp);
        final Map<String, String[]> adv = Config.advanced(sp);
        final Set<String> targets = new LinkedHashSet<>(perapp.keySet());
        targets.addAll(adv.keySet());
        new Thread(() -> {
            boolean saved = Config.save(sp, on, perapp, adv);
            for (String p : targets) if (!p.equals(getPackageName())) RootLog.su("am force-stop " + p);
            String r = (saved ? "OK" : "FAIL") + " master=" + (on ? "on" : "off") + " apps=" + targets.size();
            RootLog.log(this, "MASTER " + r);
            runOnUiThread(() -> status(r));
        }).start();
    }

    private void confirmRemove(final String pkg) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus app?")
                .setMessage("Hapus " + pkg + " dari daftar spoofing?")
                .setPositiveButton("Hapus", (d, w) -> removePkgs(Collections.singleton(pkg)))
                .setNegativeButton("Batal", null).show();
    }

    private void confirmClearAll() {
        new AlertDialog.Builder(this)
                .setTitle("Clear all")
                .setMessage("Semua konfigurasi spoofing akan dihapus dan app di-force-stop.")
                .setPositiveButton("Clear all", (d, w) -> {
                    Set<String> all = new LinkedHashSet<>(Config.perApp(sp).keySet());
                    all.addAll(Config.advanced(sp).keySet());
                    removePkgs(all);
                })
                .setNegativeButton("Batal", null).show();
    }

    private void removePkgs(final Set<String> pkgs) {
        new Thread(() -> {
            Map<String, String> perapp = new LinkedHashMap<>(Config.perApp(sp));
            Map<String, String[]> adv = new LinkedHashMap<>(Config.advanced(sp));
            for (String p : pkgs) { perapp.remove(p); adv.remove(p); }
            boolean saved = Config.save(sp, Config.enabled(sp), perapp, adv);
            for (String p : pkgs) if (!p.equals(getPackageName())) RootLog.su("am force-stop " + p);
            String r = (saved ? "OK" : "FAIL") + " removed=" + pkgs;
            RootLog.log(this, "REMOVE " + r);
            runOnUiThread(() -> { status(r); refresh(); });
        }).start();
    }

    private void showCustomDialog() {
        final String[] hints = {"Profile name", "BRAND", "MANUFACTURER", "DEVICE", "MODEL",
                "FINGERPRINT (Optional)", "PRODUCT (Optional)"};
        final EditText[] f = new EditText[hints.length];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        for (int i = 0; i < hints.length; i++) {
            f[i] = new EditText(this);
            f[i].setHint(hints[i]);
            f[i].setSingleLine(true);
            box.addView(f[i]);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("Add Custom Spoof Profile")
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> {
                    for (int i = 0; i < 5; i++) {
                        if (f[i].getText().toString().trim().isEmpty()) {
                            status("FAIL profil kustom: " + hints[i] + " wajib diisi");
                            return;
                        }
                    }
                    List<Profiles.Device> list = new ArrayList<>(Config.custom(sp));
                    list.add(new Profiles.Device("CUSTOM_" + System.currentTimeMillis(),
                            f[0].getText().toString().trim(), f[1].getText().toString().trim(),
                            f[2].getText().toString().trim(), f[3].getText().toString().trim(),
                            f[4].getText().toString().trim(), f[6].getText().toString().trim(),
                            f[5].getText().toString().trim()));
                    boolean ok = Config.saveCustom(sp, list);
                    reloadModels();
                    status(ok ? "OK profil kustom disimpan" : "FAIL profil kustom gagal disimpan");
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ diagnosa

    private static String sysProp(String key) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            return String.valueOf(c.getMethod("get", String.class).invoke(null, key));
        } catch (Throwable t) {
            return "n/a (" + t.getClass().getSimpleName() + ")";
        }
    }

    private static String getprop(String key) {
        String s = RootLog.shOut("getprop", key);
        return s == null ? "n/a" : s.trim();
    }

    /** Menampilkan nilai yang DILIHAT proses app ini lewat tiga jalur: Java, SystemProperties, shell/native. */
    private void runProbe() {
        StringBuilder sb = new StringBuilder();
        sb.append("[Java Build]\n")
                .append("MODEL=").append(Build.MODEL).append('\n')
                .append("BRAND=").append(Build.BRAND).append('\n')
                .append("DEVICE=").append(Build.DEVICE).append('\n')
                .append("PRODUCT=").append(Build.PRODUCT).append('\n')
                .append("HARDWARE=").append(Build.HARDWARE).append('\n')
                .append("BOARD=").append(Build.BOARD).append('\n');
        if (Build.VERSION.SDK_INT >= 31) {
            sb.append("SOC_MANUFACTURER=").append(Build.SOC_MANUFACTURER).append('\n')
                    .append("SOC_MODEL=").append(Build.SOC_MODEL).append('\n');
        }
        sb.append("[Java SystemProperties]\n")
                .append("ro.product.model=").append(sysProp("ro.product.model")).append('\n')
                .append("ro.soc.model=").append(sysProp("ro.soc.model")).append('\n')
                .append("ro.board.platform=").append(sysProp("ro.board.platform")).append('\n');
        sb.append("[Shell getprop, tidak bisa di-hook Java]\n")
                .append("ro.product.model=").append(getprop("ro.product.model")).append('\n')
                .append("ro.board.platform=").append(getprop("ro.board.platform"));
        tvProbe.setText(sb.toString());
        probeGl();
    }

    private void probeGl() {
        final GLSurfaceView g = new GLSurfaceView(this);
        g.setEGLContextClientVersion(2);
        g.setRenderer(new GLSurfaceView.Renderer() {
            private boolean done;

            @Override
            public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
                if (done) return;
                done = true;
                String r1, r2, v2;
                try { r1 = gl.glGetString(GL10.GL_RENDERER); } catch (Throwable t) { r1 = "n/a"; }
                try {
                    r2 = GLES20.glGetString(GLES20.GL_RENDERER);
                    v2 = GLES20.glGetString(GLES20.GL_VENDOR);
                } catch (Throwable t) { r2 = "n/a"; v2 = "n/a"; }
                final String out = "\n[GL]\nGL10 renderer=" + r1 + "\nGLES20 renderer=" + r2
                        + "\nGLES20 vendor=" + v2;
                runOnUiThread(() -> { tvProbe.append(out); probeHost.removeView(g); });
            }

            @Override public void onSurfaceChanged(GL10 gl, int w, int h) { }
            @Override public void onDrawFrame(GL10 gl) { }
        });
        g.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        probeHost.addView(g, new LinearLayout.LayoutParams(1, 1));
    }

    private void showLog() {
        tvProbe.setText("Membaca log...");
        new Thread(() -> {
            String a = RootLog.suOut("tail -n 15 " + Config.LOG_FILE);
            String b = RootLog.tailLocal(this, 10);
            final String text = "[" + Config.LOG_FILE + "]\n"
                    + (a == null || a.trim().isEmpty() ? "(kosong atau tidak terbaca)\n" : a)
                    + "[log lokal modul]\n" + b;
            runOnUiThread(() -> tvProbe.setText(text));
        }).start();
    }
}
